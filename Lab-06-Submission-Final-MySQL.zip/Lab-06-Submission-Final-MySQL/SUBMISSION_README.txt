LAB 06 - Laravel Authentication Lab
IT Student Portal - Completed Submission Files

Files included:
1. routes/web.php
2. app/Http/Controllers/AuthController.php
3. resources/views/auth/register.blade.php
4. resources/views/auth/login.blade.php
5. resources/views/dashboard.blade.php
6. .env.example
7. database/it_auth_lab.sql
8. database/DATABASE_SETUP.txt

What I completed:
- Register route and form
- Login route and form
- Logout route and form
- Guest and auth middleware
- CSRF protection on POST forms
- Registration validation
- Unique email validation
- Password minimum 8 characters and confirmation
- Password hashing with Hash::make()
- Saving registered users into the MySQL users table with $user->save()
- Login with Auth::attempt()
- Session regeneration after login
- Protected dashboard showing the logged-in user's name and email
- Logout with session invalidation and CSRF token regeneration
- MySQL connection settings for the it_auth_lab database

Simple explanation of the database part:
The .env file tells Laravel which MySQL database to use.
For this lab the database name is it_auth_lab.
Laravel's default migration creates the users table when php artisan migrate is run.
When a user fills the register form, I validate the data first.
Then I make a new User object and set the name and email.
I use Hash::make() for the password because the real password should not be saved directly.
Finally, $user->save() stores the new account in the users table.

Important:
This package contains the completed source files requested by the lab.
To actually run the website, these files should be placed inside a Laravel 12 project with PHP, Composer and MySQL available.
